using UnityEngine;

public class Bala4 : MonoBehaviour
{
    [Header("Efeitos")]
    public AudioClip hitSound;
    public GameObject hitParticles;
    public float destroyDelay = 1f;

    private bool hasCollided = false;
    private AudioSource audioSource;

    void Start()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
        audioSource.spatialBlend = 1f;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (hasCollided) return;
        hasCollided = true;

        if (hitSound != null)
            audioSource.PlayOneShot(hitSound);

  
        if (hitParticles != null)
        {
            GameObject particles = Instantiate(
                hitParticles,
                collision.contacts[0].point,
                Quaternion.identity
            );

            ParticleSystem ps = particles.GetComponent<ParticleSystem>();
            if (ps != null)
                Destroy(particles, ps.main.duration + ps.main.startLifetime.constant);
            else
                Destroy(particles, 2f);
        }

        Destroy(gameObject, destroyDelay);
    }
}
