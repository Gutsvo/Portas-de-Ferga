using UnityEngine;

public class Derrubaveis : MonoBehaviour
{
    [Header("Configura��es")]
    public int hitsToDeactivate = 3;
    public GameObject objectToActivate;
    public GameObject objectToDeactivate;

    private int hitCount = 0;

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.CompareTag("Bala"))
        {
            hitCount++;

            if (hitCount >= hitsToDeactivate)
            {
                if (objectToDeactivate != null)
                    objectToDeactivate.SetActive(false);

                if (objectToActivate != null)
                    objectToActivate.SetActive(true);
            }
        }
    }
}
