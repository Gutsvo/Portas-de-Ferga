using UnityEngine;
using TMPro;

public class DeathTimerUI : MonoBehaviour
{
    [Header("Tempo total em segundos")]
    public float totalTime = 30f;

    private float currentTime;

    [Header("Texto do Timer (TextMeshPro)")]
    public TextMeshProUGUI timerText; // arraste o texto aqui

    [Header("Menu de morte")]
    public GameObject deathMenu;

    private void Start()
    {
        currentTime = totalTime;

        if (deathMenu != null)
            deathMenu.SetActive(false);
    }

    private void Update()
    {
        // Diminui o tempo
        currentTime -= Time.deltaTime;

        if (currentTime < 0)
            currentTime = 0;

        // Atualiza o texto
        UpdateTimerUI();

        // Quando zerar, ativa o menu
        if (currentTime <= 0)
        {
            TriggerDeathMenu();
        }
    }

    private void UpdateTimerUI()
    {
        int minutes = Mathf.FloorToInt(currentTime / 60);
        int seconds = Mathf.FloorToInt(currentTime % 60);

        timerText.text = $"{minutes:00}:{seconds:00}";
    }

    private void TriggerDeathMenu()
    {
        Time.timeScale = 0f; // Pausa o jogo
        deathMenu.SetActive(true); // Mostra o menu
    }
}
