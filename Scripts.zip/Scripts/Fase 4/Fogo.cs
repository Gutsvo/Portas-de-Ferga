using UnityEngine;

public class Fogo : MonoBehaviour
{
    [Header("Dano")]
    public int damage = 100;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            var vida = other.GetComponent<Vidas>();
            var vida4 = other.GetComponent<Vidas4>();

            if (vida && vida4 != null)
            {
                vida.TakeDamage(damage);
                Debug.Log("Fogo deu dano!");
            }
            else
            {
                Debug.Log("Player n�o tem componente Vidas.");
            }

            if (vida4 != null)
            {
                vida4.TakeDamage(damage);
                Debug.Log("Fogo deu dano!");
            }
            else
            {
                Debug.Log("Player n�o tem componente Vidas.");
            }
        }
    }
}
