using UnityEngine;

public class Estilingue4 : MonoBehaviour
{
    [Header("Projectile Settings")]
    public GameObject projectilePrefab;
    public Transform shootPoint;
    public float minForce = 10f;
    public float maxForce = 40f;
    public float chargeSpeed = 20f;
    public float shotCooldown = 0.5f;

    [Header("Trajectory")]
    public LineRenderer trajectoryLine;
    public int trajectoryPoints = 25;
    public float timeStep = 0.05f;

    [Header("References")]
    public ThirdPersonController4 playerController;
    public CameraController camController;
    public Transform shoulderCameraPivot;
    public float aimingSlowMultiplier = 0.35f;

    private float currentForce = 0f;
    private bool isAiming = false;
    private float cooldownTimer = 0f;

    private Vector3 defaultCameraLocalPos;

    float originalSpeed;

    void Start()
    {
        currentForce = minForce;
        defaultCameraLocalPos = camController.transform.localPosition;
        originalSpeed = playerController.velocity;

        if (trajectoryLine != null)
        {
            trajectoryLine.positionCount = trajectoryPoints;
            trajectoryLine.enabled = false;
        }
    }

    void Update()
    {
        cooldownTimer -= Time.deltaTime;

        if (Input.GetMouseButtonDown(0))
            StartAiming();

        if (Input.GetMouseButton(0))
            ChargeShot();

        if (Input.GetMouseButtonUp(0))
            ReleaseShot();
    }

    void StartAiming()
    {
        if (cooldownTimer > 0f) return;

        isAiming = true;
        currentForce = minForce;

        playerController.velocity = originalSpeed * aimingSlowMultiplier;

        camController.transform.localPosition = shoulderCameraPivot.localPosition;

        if (trajectoryLine != null)
            trajectoryLine.enabled = true;
    }

    void ChargeShot()
    {
        if (!isAiming) return;

        currentForce += chargeSpeed * Time.deltaTime;
        currentForce = Mathf.Clamp(currentForce, minForce, maxForce);

        DisplayTrajectory();
    }

    void ReleaseShot()
    {
        if (!isAiming) return;

        isAiming = false;
        cooldownTimer = shotCooldown;

        FireProjectile();

        playerController.velocity = originalSpeed;

        camController.transform.localPosition = defaultCameraLocalPos;

        if (trajectoryLine != null)
            trajectoryLine.enabled = false;
    }

    void FireProjectile()
    {
        GameObject proj = Instantiate(projectilePrefab, shootPoint.position, shootPoint.rotation);

        Rigidbody rb = proj.GetComponent<Rigidbody>();
        rb.linearVelocity = shootPoint.forward * currentForce;
    }

    void DisplayTrajectory()
    {
        if (trajectoryLine == null) return;

        Vector3 startPos = shootPoint.position;
        Vector3 startVel = shootPoint.forward * currentForce;

        for (int i = 0; i < trajectoryPoints; i++)
        {
            float t = i * timeStep;
            Vector3 point = startPos + startVel * t + 0.5f * Physics.gravity * t * t;
            trajectoryLine.SetPosition(i, point);
        }
    }
}
