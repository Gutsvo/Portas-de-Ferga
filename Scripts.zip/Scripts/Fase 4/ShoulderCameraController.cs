using UnityEngine;

public class ShoulderCamera : MonoBehaviour
{
    public Transform target;                 // personagem
    public Transform pointShoot;
    public float distance = 20f;
    public float height = 80f;
    public float shoulderOffset = 5f;

    public float sensitivity = 150f;

    private float yaw;
    private float pitch;

    public float minPitch = -30f;
    public float maxPitch = 60f;

    // Limite horizontal (em graus) para olhar para os lados
    // Ex: 90 = pode olhar 45� para cada lado
    public float yawLimit = 90f;

    void Start()
    {
        // Come�a alinhada com a dire��o do alvo
        yaw = target.eulerAngles.y;
    }

    void LateUpdate()
    {
        if (!target) return;

        // Entrada do mouse
        yaw += Input.GetAxis("Mouse X") * sensitivity * Time.deltaTime;
        pitch -= Input.GetAxis("Mouse Y") * sensitivity * Time.deltaTime;

        // Limita rota��o vertical
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

        // Calcula yaw relativo ao personagem
        float targetY = target.eulerAngles.y;
        float relativeYaw = Mathf.DeltaAngle(targetY, yaw);

        // Limita yaw para que a c�mera n�o veja a frente do jogador
        relativeYaw = Mathf.Clamp(relativeYaw, -yawLimit * 0.5f, yawLimit * 0.5f);

        // Reconstr�i a rota��o final
        yaw = targetY + relativeYaw;

        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0);

        // Calcula posi��o atr�s do personagem + offset de ombro
        Vector3 position =
            target.position
            - rotation * Vector3.forward * distance
            + Vector3.up * height
            + transform.right * shoulderOffset;

        transform.position = position;
        transform.rotation = rotation;

        if (pointShoot != null)
        {
            pointShoot.rotation = rotation;
        }
    }
}
