using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;

public class Cutscene4 : MonoBehaviour
{
    public VideoPlayer video;

    void Start()
    {
        video.Play(); // for�a o in�cio
        video.loopPointReached += EndVideo;
    }

    void EndVideo(VideoPlayer vp)
    {
        SceneManager.LoadScene("Fuga");
    }
}