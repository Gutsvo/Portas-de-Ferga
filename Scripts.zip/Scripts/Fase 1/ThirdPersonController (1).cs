﻿using UnityEngine;

public class ThirdPersonController4 : MonoBehaviour
{
    public float velocity = 50f;
    public float jumpForce = 18f;
    public float jumpTime = 0.85f;
    public float gravity = 9.8f;

    float jumpElapsedTime = 0;
    bool isJumping = false;

    float inputHorizontal;
    float inputVertical;
    bool inputJump;

    Animator animator;
    CharacterController cc;

    // ----------- AQUI É A ÚNICA PARTE NOVA -----------
    [Header("Cameras")]
    public Camera mainCamera;   // Arraste sua câmera normal
    public Camera aimCamera;    // Arraste sua câmera de mira
    // --------------------------------------------------

    void Start()
    {
        cc = GetComponent<CharacterController>();
        animator = GetComponent<Animator>();

        if (animator == null)
            Debug.LogWarning("Animator faltando no player.");

        // --- CÂMERAS (única modificação real do script) ---
        if (mainCamera != null) mainCamera.enabled = true;
        if (aimCamera != null) aimCamera.enabled = false;
    }

    void Update()
    {
        // ----------- TROCA DE CÂMERA (única lógica adicionada) -----------
        bool isAiming = Input.GetMouseButton(1);

        if (mainCamera != null) mainCamera.enabled = !isAiming;
        if (aimCamera != null) aimCamera.enabled = isAiming;
        // -----------------------------------------------------------------

        // Inputs
        inputHorizontal = Input.GetAxis("Horizontal");
        inputVertical = Input.GetAxis("Vertical");
        inputJump = Input.GetButton("Jump");

        // --- ANIMAÇÕES ---
        if (animator != null)
        {
            bool isMoving = Mathf.Abs(inputHorizontal) > 0.1f || Mathf.Abs(inputVertical) > 0.1f;
            animator.SetBool("run", isMoving);

            bool isIdle = !isMoving && cc.isGrounded;
            animator.SetBool("Idle", isIdle);

            animator.SetBool("air", !cc.isGrounded);
        }

        // Pulo apenas quando está no chão
        if (inputJump && cc.isGrounded)
        {
            isJumping = true;
        }

        HeadHittingDetect();
    }

    void FixedUpdate()
    {
        float directionX = inputHorizontal * velocity * Time.deltaTime;
        float directionZ = inputVertical * velocity * Time.deltaTime;
        float directionY = 0;

        Vector2 rawInput = new Vector2(inputHorizontal, inputVertical);

        if (rawInput.magnitude > 1f)
            rawInput.Normalize();

        inputHorizontal = rawInput.x;
        inputVertical = rawInput.y;

        // Jump curve
        if (isJumping)
        {
            directionY = Mathf.SmoothStep(jumpForce, jumpForce * 0.30f,
                                          jumpElapsedTime / jumpTime) * Time.deltaTime;

            jumpElapsedTime += Time.deltaTime;
            if (jumpElapsedTime >= jumpTime)
            {
                isJumping = false;
                jumpElapsedTime = 0;
            }
        }

        directionY -= gravity * Time.deltaTime;

        // ----------- AQUI ALTEREI APENAS A CÂMERA USADA -----------
        Camera activeCam = (aimCamera != null && aimCamera.enabled) ? aimCamera : mainCamera;
        // ----------------------------------------------------------

        // --- ROTATION based on camera ---
        Vector3 forward = activeCam.transform.forward;
        Vector3 right = activeCam.transform.right;

        forward.y = 0;
        right.y = 0;

        forward.Normalize();
        right.Normalize();

        forward *= directionZ;
        right *= directionX;

        if (directionX != 0 || directionZ != 0)
        {
            float angle = Mathf.Atan2(forward.x + right.x, forward.z + right.z) * Mathf.Rad2Deg;
            Quaternion rotation = Quaternion.Euler(0, angle, 0);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 0.15f);
        }

        Vector3 verticalDirection = Vector3.up * directionY;
        Vector3 horizontalDirection = forward + right;

        cc.Move(verticalDirection + horizontalDirection);
    }

    void HeadHittingDetect()
    {
        float headHitDistance = 1.1f;
        Vector3 ccCenter = transform.TransformPoint(cc.center);
        float hitCalc = cc.height / 2f * headHitDistance;

        if (Physics.Raycast(ccCenter, Vector3.up, hitCalc))
        {
            jumpElapsedTime = 0;
            isJumping = false;
        }
    }
}
