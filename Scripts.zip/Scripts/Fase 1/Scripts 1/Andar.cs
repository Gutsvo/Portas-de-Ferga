using UnityEngine;

public class Movimentar : MonoBehaviour
{
    public float speed = 5f;
    public float mouseSensitivity = 200f;
    public Transform cameraTransform;

    float xRotation = 0f;
    CharacterController controller;
    Vector3 velocity;
    float gravity = -9.81f;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // -------- MOUSE LOOK --------
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        cameraTransform.localRotation = Quaternion.Euler(xRotation, 0, 0);
        transform.Rotate(Vector3.up * mouseX);

        // -------- MOVIMENTA��O --------
        float x = Input.GetAxis("Horizontal");  // A / D
        float z = Input.GetAxis("Vertical");    // W / S

        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move * speed * Time.deltaTime);

        // -------- GRAVIDADE --------
        if (controller.isGrounded && velocity.y < 0)
            velocity.y = -2f;

        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }
}
