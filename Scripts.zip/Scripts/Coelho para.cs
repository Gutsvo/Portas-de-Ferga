﻿using UnityEngine;
using UnityEngine.AI;

public class CoelhoAnimationController : MonoBehaviour
{
    public Animator animator;
    public Coelho coelho;            // referência ao script principal
    public NavMeshAgent agent;

    private int lastHealth;

    void Start()
    {
        if (agent == null) agent = GetComponent<NavMeshAgent>();
        if (coelho == null) coelho = GetComponent<Coelho>();

        lastHealth = coelho.GetCurrentHealth();
    }

    void Update()
    {
        AtualizarMovimento();
        DetectarDano();
    }

    void AtualizarMovimento()
    {
        // Velocidade do agente
        float speed = agent.velocity.magnitude;

        // Se estiver andando
        if (speed > 0.1f)
        {
            animator.SetBool("Run", true);
            animator.SetBool("Idle", false);
        }
        else
        {
            animator.SetBool("Run", false);
            animator.SetBool("Idle", true);
        }
    }

    void DetectarDano()
    {
        int vidaAtual = coelho.GetCurrentHealth();

        if (vidaAtual < lastHealth) // perdeu vida → tomou dano
        {
            animator.SetTrigger("Hit");
        }

        lastHealth = vidaAtual;
    }
}
