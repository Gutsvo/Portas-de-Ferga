using UnityEngine;

public class CameraOrbit : MonoBehaviour
{
    public Transform target;       // o player
    public Vector3 offset = new Vector3(0, 2, -4);
    public float mouseSensitivity = 200f;
    public float distance = 4f;

    float rotationX = 0f;
    float rotationY = 0f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void LateUpdate()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        rotationY += mouseX;        // gira ao redor do player
        rotationX -= mouseY;        // sobe/desce
        rotationX = Mathf.Clamp(rotationX, -30f, 60f);

        // cria uma rota��o baseada no mouse
        Quaternion rotation = Quaternion.Euler(rotationX, rotationY, 0);

        // posiciona a c�mera ao redor do player
        transform.position = target.position + rotation * new Vector3(0, offset.y, -distance);

        // sempre olhar para o player
        transform.LookAt(target.position + Vector3.up * offset.y);
    }
}
