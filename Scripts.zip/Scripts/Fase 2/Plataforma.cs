using UnityEngine;

public class PlataformaMovel : MonoBehaviour
{
    [Header("Pontos de Movimento")]
    public Transform pontoA;      // Primeiro destino
    public Transform pontoB;      // Segundo destino

    [Header("Configura��es")]
    public float velocidade = 3f;

    private Vector3 posInicial;
    private Vector3 destinoAtual;

    void Start()
    {
        posInicial = transform.position;   // Guarda a posi��o original
        destinoAtual = pontoA.position;    // Primeiro destino
    }

    void Update()
    {
        // Move a plataforma at� o destino
        transform.position = Vector3.MoveTowards(
            transform.position,
            destinoAtual,
            velocidade * Time.deltaTime
        );

        // Se chegou no destino, muda para o pr�ximo
        if (Vector3.Distance(transform.position, destinoAtual) < 0.05f)
        {
            if (destinoAtual == pontoA.position)
                destinoAtual = posInicial;    // Volta para origem
            else if (destinoAtual == posInicial)
                destinoAtual = pontoB.position; // Vai para o ponto B
            else
                destinoAtual = pontoA.position; // Volta para o ponto A
        }
    }

    // Gizmos s� para visualizar no editor
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        if (pontoA != null)
            Gizmos.DrawWireSphere(pontoA.position, 0.2f);
        if (pontoB != null)
            Gizmos.DrawWireSphere(pontoB.position, 0.2f);
    }
}
