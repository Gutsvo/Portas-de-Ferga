﻿using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class Coelho : MonoBehaviour
{
    [Header("References")]
    public NavMeshAgent agent;
    public Transform player;

    [Header("Vida do inimigo")]
    public int maxHealth = 5;
    private int currentHealth;

    [Header("Pontos fracos (Triggers de Dano)")]
    public GameObject[] damageTriggers = new GameObject[4];

    [Header("Ataque Corpo-a-Corpo")]
    public float meleeRange = 2f;
    public int meleeDamage = 1;
    public float meleeCooldown = 1f;
    private bool canMelee = true;

    [Header("Ataque à Distância")]
    public float attackRange = 10f;         // distância para começar a atirar
    public float timeBetweenAttacks = 1.5f; // cadência
    private bool alreadyAttacked;

    public GameObject projectile;           // prefab da bola de fogo
    public Transform firePoint;             // posição de spawn

    private void Awake()
    {
        if (agent == null)
            agent = GetComponent<NavMeshAgent>();

        if (player == null)
            Debug.LogWarning("Player não atribuído ao inimigo!");

        currentHealth = maxHealth;
    }

    private void Update()
    {
        if (player == null) return;

        float distance = Vector3.Distance(transform.position, player.position);

        // MELEE
        if (distance <= meleeRange)
        {
            agent.SetDestination(transform.position);
            MeleeAttack();
            return;
        }

        // LONG RANGE ATACK
        if (distance <= attackRange)
        {
            FollowPlayer();
            RangedAttack();
            return;
        }

        // SE ESTIVER LONGE DE MAIS → SÓ ANDA
        FollowPlayer();
    }

    private void FollowPlayer()
    {
        agent.SetDestination(player.position);
    }

    private void MeleeAttack()
    {
        if (!canMelee) return;

        player.GetComponent<Vidas>().TakeDamage(meleeDamage);

        canMelee = false;
        Invoke(nameof(ResetMelee), meleeCooldown);
    }

    private void ResetMelee()
    {
        canMelee = true;
    }

    private void RangedAttack()
    {
        if (alreadyAttacked) return;

        agent.SetDestination(transform.position);
        transform.LookAt(player);

        // dispara a bola de fogo
        Rigidbody rb = Instantiate(projectile, firePoint.position, firePoint.rotation)
                       .GetComponent<Rigidbody>();

        rb.AddForce(firePoint.forward * 25f, ForceMode.Impulse);

        alreadyAttacked = true;
        Invoke(nameof(ResetRangedAttack), timeBetweenAttacks);
    }

    private void ResetRangedAttack()
    {
        alreadyAttacked = false;
    }

    public void TakeDamage(int amount)
    {
        currentHealth -= amount;

        if (currentHealth <= 0)
            Invoke(nameof(DestroyEnemy), 0.3f);
    }

    private void DestroyEnemy()
    {
        Destroy(gameObject);

        SceneManager.LoadScene("Cutscene 4");
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!collision.collider.CompareTag("Bala"))
            return;

        foreach (GameObject trigger in damageTriggers)
        {
            if (trigger != null && collision.gameObject == trigger)
            {
                TakeDamage(1);
                break;
            }
        }
    }

    public int GetCurrentHealth()
    {
        return currentHealth;
    }
}
