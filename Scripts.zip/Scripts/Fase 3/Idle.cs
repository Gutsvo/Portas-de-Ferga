using UnityEngine;

public class IdleAnimation : MonoBehaviour
{
    private Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {
       
        animator.SetBool("Idle", true);
    }
}
