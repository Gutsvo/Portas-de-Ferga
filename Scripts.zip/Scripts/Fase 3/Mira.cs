﻿using UnityEngine;

public class PlayerPullShoot : MonoBehaviour
{
    public Animator playerAnim; // Animator da PERSONAGEM

    void Update()
    {
        // Quando come�ar a puxar (pressionar o mouse)
        if (Input.GetMouseButtonDown(0))
        {
            playerAnim.SetTrigger("Pull");
        }

        // Quando soltar e disparar
        if (Input.GetMouseButtonUp(0))
        {
            playerAnim.SetTrigger("Shoot");
        }
    }
}
