using UnityEngine;

public class TriggerDano : MonoBehaviour
{
    public Coelho enemy;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.CompareTag("Bala"))
        {
            enemy.TakeDamage(1);
            Debug.Log("O inimigo sofreu dano! Vida atual: " + enemy.GetCurrentHealth());
        }
    }
}
