using UnityEngine;

public class Vidas : MonoBehaviour
{
    public int maxHealth = 5;
    private int currentHealth;

    [Header("Menu de Morte")]
    public GameObject deathMenu;   // Arrasta aqui o Canvas do menu

    private void Awake()
    {
        currentHealth = maxHealth;

        if (deathMenu != null)
            deathMenu.SetActive(false);
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0)
            Die();
    }

    private void Die()
    {
        Time.timeScale = 0f;

        if (deathMenu != null)
            deathMenu.SetActive(true);

        Debug.Log("A protagonista morreu.");
    }

}
