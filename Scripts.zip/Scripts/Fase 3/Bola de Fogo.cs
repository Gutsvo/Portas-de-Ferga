using UnityEngine;

public class BoladeFogo : MonoBehaviour
{
    [Header("Movimenta��o")]
    public float speed = 20f;

    [Header("Dano")]
    public int damage = 1;

    private Rigidbody rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.linearVelocity = transform.forward * speed;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.CompareTag("Player"))
        {
            collision.collider.GetComponent<Vidas>().TakeDamage(damage);
        }

        Destroy(gameObject);
    }
}
